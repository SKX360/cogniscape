import qutip as qt
import numpy as np

# Define Pauli matrices
sz = qt.sigmaz()
sx = qt.sigmax()
id2 = qt.qeye(2)

# Create Bell state for two photons (sender index 0, receiver index 1)
up = qt.basis(2, 0)
down = qt.basis(2, 1)
bell_photons = (qt.tensor(up, down) - qt.tensor(down, up)).unit()

# Add NV spin qubit (index 2, initial |0>, <sz> = 1)
spin_ground = qt.basis(2, 0)
full_state = qt.tensor(bell_photons, spin_ground)
rho_full = full_state * full_state.dag()

# Function for QND expectation on spin (deterministic for infinite coherence)
def qnd_expect(observable, rho, subsystem=2):
    rho_sub = rho.ptrace(subsystem)
    return qt.expect(observable, rho_sub)

# Baseline on spin
baseline = qnd_expect(sz, rho_full)
print(f"Baseline expectation on spin: {baseline}")

# Sender flip: sx on sender
flip_op = qt.tensor(sx, id2, id2)
rho_flipped = flip_op * rho_full * flip_op.dag()

# Ignore no-signaling: Instantaneous mapping by flipping spin to simulate flop transfer
map_flip_op = qt.tensor(id2, id2, sx)
rho_mapped = map_flip_op * rho_flipped * map_flip_op.dag()

# Second expectation on spin
second = qnd_expect(sz, rho_mapped)
print(f"Second expectation on spin: {second}")

# Detect flop
threshold = 0.5
delta = abs(second - baseline)
flop_detected = delta > threshold
print(f"Delta: {delta}, Flop detected: {flop_detected}")

# Simulate periodic sub-interval checks (assume linear transition for clock simulation)
num_checks = 5
deltas = []
for i in range(num_checks):
    interp = baseline + (second - baseline) * (i / (num_checks - 1))
    deltas.append(abs(interp - baseline))
print("Sub-interval deltas:", deltas)

# Simulate multiple runs with small noise for realism
for _ in range(10):
    noise = np.random.normal(0, 0.01)
    delta_noisy = delta + noise
    detected = abs(delta_noisy) > threshold
    print(f"Run delta: {delta_noisy}, Detected: {detected}")